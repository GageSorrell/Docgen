/**
 * Programmatic TypeDoc discovery and normalization.
 *
 * @module @sorrell/docs-api-reference/TypeDoc
 *
 * @file      TypeDoc.ts
 * @author    Gage Sorrell <gage@sorrell.sh>
 * @copyright (c) 2026 Gage Sorrell
 * @license   MIT
 */
import { Application, ReflectionKind, TSConfigReader, TypeDocReader } from "typedoc";
import { readFile } from "node:fs/promises";
import { basename, dirname, join, parse, relative, resolve, sep } from "node:path";
import { createApiDataset, validateApiRecords } from "./Serialization.js";
import { ApiReferenceError } from "./Errors.js";
const textOf = (reflection) => reflection?.comment?.summary
    ?.map((part) => part.text ?? "")
    .join("")
    .trim() ?? "";
const sourceOf = (reflection, repositoryUrl, revision, sourceRoot) => {
    const source = reflection?.sources?.[0];
    if (source?.fileName === undefined ||
        repositoryUrl === undefined ||
        revision === undefined) {
        return undefined;
    }
    const rawFile = source.fileName.replaceAll("\\", "/");
    const normalizedRoot = sourceRoot?.replaceAll("\\", "/").replace(/\/$/, "");
    const file = normalizedRoot !== undefined && rawFile.startsWith(`${normalizedRoot}/`)
        ? rawFile.slice(normalizedRoot.length + 1)
        : rawFile;
    return {
        file,
        repositoryUrl,
        revision,
        ...(source.line === undefined ? {} : { line: source.line })
    };
};
const sourceFromPath = (fileName, repositoryUrl, revision, sourceRoot) => {
    if (fileName === undefined || repositoryUrl === undefined || revision === undefined || sourceRoot === undefined) {
        return undefined;
    }
    const file = relative(resolve(sourceRoot), resolve(fileName));
    if (file === "" || file === ".." || file.startsWith(`..${sep}`) || file.startsWith("../")) {
        return undefined;
    }
    return {
        file: file.replaceAll("\\", "/"),
        repositoryUrl,
        revision
    };
};
const recordLike = (value) => value !== null && typeof value === "object" && !Array.isArray(value)
    ? value
    : undefined;
const exportTarget = (value) => {
    if (typeof value === "string") {
        return value;
    }
    const conditions = recordLike(value);
    if (conditions === undefined) {
        return undefined;
    }
    for (const condition of ["types", "import", "node", "default", "require"]) {
        const target = exportTarget(conditions[condition]);
        if (target !== undefined) {
            return target;
        }
    }
    return undefined;
};
const manifestFor = async (entryPoints, packageName) => {
    for (const entryPoint of entryPoints) {
        let directory = dirname(resolve(entryPoint));
        while (true) {
            try {
                const content = await readFile(join(directory, "package.json"), "utf8");
                const manifest = JSON.parse(content);
                if (manifest.name === undefined || manifest.name === packageName) {
                    return { directory, manifest };
                }
            }
            catch {
                // Continue toward the workspace root when no package manifest exists here.
            }
            const parent = dirname(directory);
            if (parent === directory) {
                break;
            }
            directory = parent;
        }
    }
    return undefined;
};
const packageModuleEntryPoint = async (packageInput) => {
    const located = await manifestFor(packageInput.entryPoints, packageInput.name);
    if (located === undefined) {
        return undefined;
    }
    const { directory, manifest } = located;
    const exportsMap = recordLike(manifest.exports);
    const target = exportsMap !== undefined && Object.hasOwn(exportsMap, ".")
        ? exportTarget(exportsMap["."])
        : typeof manifest.exports === "string"
            ? manifest.exports
            : manifest.main;
    if (target === undefined) {
        return undefined;
    }
    const targetPath = resolve(directory, target);
    const normalizedTarget = targetPath.replaceAll("\\", "/");
    const normalizedEntries = packageInput.entryPoints.map((entryPoint) => {
        const absolute = resolve(entryPoint);
        const relative = absolute.startsWith(`${directory}${sep}`)
            ? absolute.slice(directory.length + 1)
            : basename(absolute);
        return { absolute, relative: relative.replaceAll("\\", "/") };
    });
    const exact = normalizedEntries.find(({ absolute }) => absolute === targetPath);
    if (exact !== undefined) {
        return exact.absolute;
    }
    const targetName = parse(normalizedTarget).name.replace(/\.d$/u, "");
    const sameName = normalizedEntries.filter(({ relative }) => parse(relative).name.replace(/\.d$/u, "") === targetName);
    if (sameName.length === 1) {
        return sameName[0]?.absolute;
    }
    const normalizedTargetStem = normalizedTarget
        .replace(/\.(?:d\.)?[cm]?[jt]sx?$/iu, "")
        .replace(/\/(?:distribution|dist|build|lib)\//giu, "/");
    const matchingSuffix = normalizedEntries.filter(({ relative }) => normalizedTargetStem.endsWith(`/${relative.replace(/\.(?:d\.)?[cm]?[jt]sx?$/iu, "").replace(/\/(?:source|src|lib)\//giu, "/")}`));
    if (matchingSuffix.length === 1) {
        return matchingSuffix[0]?.absolute;
    }
    return packageInput.entryPoints.length === 1
        ? resolve(packageInput.entryPoints[0] ?? "")
        : undefined;
};
const moduleDescriptionFrom = async (entryPoint) => {
    if (entryPoint === undefined) {
        return undefined;
    }
    let source;
    try {
        source = await readFile(entryPoint, "utf8");
    }
    catch {
        return undefined;
    }
    const comment = source.match(/^\uFEFF?\s*\/\*\*([\s\S]*?)\*\//u)?.[1];
    if (comment === undefined) {
        return undefined;
    }
    const lines = comment
        .split(/\r?\n/u)
        .map((line) => line.replace(/^\s*\* ?/u, ""));
    const moduleTag = lines.findIndex((line) => /^\s*@module\b/u.test(line));
    if (moduleTag < 0 || lines.slice(0, moduleTag).some((line) => /^\s*@\w+/u.test(line))) {
        return undefined;
    }
    const description = lines.slice(0, moduleTag).join("\n").trim();
    return description === "" ? undefined : description;
};
const categoryFor = (reflection) => {
    const kind = reflection.kind;
    if (kind === ReflectionKind.Function) {
        return {
            collapsed: false,
            id: "functions",
            label: "Functions",
            order: 0
        };
    }
    if (kind === ReflectionKind.Class) {
        return { collapsed: false, id: "classes", label: "Classes", order: 1 };
    }
    if (kind === ReflectionKind.Interface) {
        return {
            collapsed: false,
            id: "interfaces",
            label: "Interfaces",
            order: 2
        };
    }
    if (kind === ReflectionKind.TypeAlias) {
        return { collapsed: false, id: "types", label: "Types", order: 3 };
    }
    if (kind === ReflectionKind.Variable || kind === ReflectionKind.Enum) {
        return {
            collapsed: false,
            id: "constants",
            label: "Constants",
            order: 4
        };
    }
    if (kind === ReflectionKind.Namespace) {
        return {
            collapsed: false,
            id: "namespaces",
            label: "Namespaces",
            order: 5
        };
    }
    return {
        collapsed: false,
        id: "other",
        label: "Other",
        order: 6
    };
};
const declarationKind = (reflection) => {
    if (reflection.kind === ReflectionKind.Function) {
        return "function";
    }
    if (reflection.kind === ReflectionKind.Class) {
        return "class";
    }
    if (reflection.kind === ReflectionKind.Interface) {
        return "interface";
    }
    if (reflection.kind === ReflectionKind.TypeAlias) {
        return "type";
    }
    if (reflection.kind === ReflectionKind.Namespace) {
        return "namespace";
    }
    return "variable";
};
const typeText = (reflection) => reflection?.type?.toString?.() ?? "unknown";
const typeParametersText = (parameters) => {
    if (parameters === undefined || parameters.length === 0) {
        return "";
    }
    return `<${parameters.map((parameter) => {
        const constraint = parameter.type?.toString?.();
        const defaultValue = parameter.defaultValue;
        return `${parameter.name ?? "T"}${constraint === undefined ? "" : ` extends ${constraint}`}${defaultValue === undefined ? "" : ` = ${defaultValue}`}`;
    }).join(", ")}>`;
};
const parameterText = (parameter) => `${parameter.flags?.isRest === true ? "..." : ""}${parameter.name ?? "value"}${parameter.flags?.isOptional === true || parameter.defaultValue !== undefined ? "?" : ""}: ${typeText(parameter)}`;
const parametersText = (parameters) => parameters === undefined || parameters.length === 0
    ? "()"
    : `(\n${parameters.map((parameter) => `    ${parameterText(parameter)}`).join(",\n")}\n)`;
const methodText = (reflection) => {
    const signature = reflection.signatures?.[0];
    if (signature === undefined) {
        return `${reflection.name ?? "unknown"}: ${typeText(reflection)};`;
    }
    const name = reflection.name ?? signature.name ?? "unknown";
    const modifiers = [
        signature.flags?.isStatic === true ? "static " : "",
        signature.flags?.isAbstract === true ? "abstract " : ""
    ].join("");
    return `${modifiers}${name}${typeParametersText(signature.typeParameters)}${parametersText(signature.parameters)}: ${typeText(signature)};`;
};
const memberText = (reflection) => {
    if (reflection.flags?.isPrivate === true) {
        return undefined;
    }
    const accessibility = reflection.flags?.isProtected === true
        ? "protected "
        : "";
    if (reflection.kind === ReflectionKind.Method) {
        return `${accessibility}${methodText(reflection)}`;
    }
    if (reflection.kind === ReflectionKind.Constructor) {
        return `${accessibility}${methodText({ ...reflection, name: "constructor" })}`;
    }
    if (reflection.kind === ReflectionKind.Accessor) {
        const accessor = reflection.signatures?.[0];
        return accessor === undefined
            ? undefined
            : `${accessibility}get ${reflection.name ?? "value"}(): ${typeText(accessor)};`;
    }
    if (reflection.kind !== ReflectionKind.Property) {
        return undefined;
    }
    return `${accessibility}${reflection.flags?.isStatic === true ? "static " : ""}${reflection.flags?.isReadonly === true ? "readonly " : ""}${reflection.name ?? "value"}${reflection.flags?.isOptional === true ? "?" : ""}: ${typeText(reflection)};`;
};
const signatureFor = (reflection) => {
    const name = reflection.name ?? "unknown";
    if (reflection.kind === ReflectionKind.Function) {
        const signature = reflection.signatures?.[0];
        if (signature !== undefined) {
            return `export declare function ${name}${typeParametersText(signature.typeParameters)}${parametersText(signature.parameters)}: ${typeText(signature)};`;
        }
    }
    if (reflection.kind === ReflectionKind.Interface || reflection.kind === ReflectionKind.Class) {
        const keyword = reflection.kind === ReflectionKind.Interface
            ? "interface"
            : "class";
        const inherited = reflection.extendedTypes
            ?.map((type) => type.toString?.())
            .filter((type) => type !== undefined) ?? [];
        const members = reflection.children
            ?.map(memberText)
            .filter((member) => member !== undefined) ?? [];
        return `export declare ${keyword} ${name}${typeParametersText(reflection.typeParameters)}${inherited.length === 0 ? "" : ` extends ${inherited.join(", ")}`} {\n${members.map((member) => `    ${member}`).join("\n")}\n}`;
    }
    if (reflection.kind === ReflectionKind.TypeAlias) {
        return `export declare type ${name}${typeParametersText(reflection.typeParameters)} = ${typeText(reflection)};`;
    }
    if (reflection.kind === ReflectionKind.Variable) {
        const variableKind = reflection.flags?.isConst === true ? "const" : "let";
        return `export declare ${variableKind} ${name}: ${typeText(reflection)};`;
    }
    if (reflection.kind === ReflectionKind.Enum) {
        const members = reflection.children?.map((member) => `${member.name ?? "value"}${member.defaultValue === undefined ? "" : ` = ${member.defaultValue}`}`) ?? [];
        return `export declare enum ${name} {\n${members.map((member) => `    ${member}`).join(",\n")}\n}`;
    }
    const kind = declarationKind(reflection);
    return `export declare ${kind} ${name}`;
};
const declarationId = (name) => {
    const normalized = name
        .replace(/[^A-Za-z0-9_$.-]+/g, "-")
        .replace(/^-+|-+$/g, "");
    return normalized === "" ? "declaration" : normalized;
};
const declarationFrom = (reflection, packageInput, categoryId, options) => {
    const name = reflection.name ?? "unknown";
    const source = sourceOf(reflection, options.repositoryUrl, options.revision, options.sourceRoot);
    return {
        categoryId,
        description: textOf(reflection) || `${name} exported by ${packageInput.name}.`,
        id: declarationId(name),
        kind: declarationKind(reflection),
        name,
        signature: signatureFor(reflection),
        ...(source === undefined ? {} : { source })
    };
};
const recordFrom = (reflection, packageInput, options, summary, selectedModuleSource) => {
    const children = [...(reflection.children ?? [])]
        .filter((child) => child.name !== undefined)
        .sort((left, right) => (left.name ?? "").localeCompare(right.name ?? ""));
    const categories = [
        ...new Map(children.map((child) => {
            const category = categoryFor(child);
            return [category.id, category];
        })).values()
    ].sort((left, right) => left.order - right.order);
    const declarations = children.map((child) => declarationFrom(child, packageInput, categoryFor(child).id, options));
    const moduleName = packageInput.id;
    const displayName = reflection.name ?? packageInput.name;
    const moduleSource = sourceOf(reflection, options.repositoryUrl, options.revision, options.sourceRoot) ?? selectedModuleSource;
    return {
        breadcrumbs: [
            {
                current: false,
                href: `${options.referencePrefix ?? "/docs/api"}/`,
                label: "API Reference"
            },
            {
                current: false,
                href: `${options.referencePrefix ?? "/docs/api"}/${packageInput.version}`,
                label: `V${packageInput.version.replace(/^[vV]/u, "")}`
            },
            {
                current: false,
                href: `${options.referencePrefix ?? "/docs/api"}/${packageInput.id}`,
                label: packageInput.name
            },
            {
                current: true,
                label: displayName
            }
        ],
        categories,
        declarations,
        displayName,
        exportCount: declarations.length,
        introductionVersion: packageInput.version,
        module: moduleName,
        packageId: packageInput.id,
        packageName: packageInput.name,
        version: packageInput.version,
        ...(summary === undefined ? {} : { summary }),
        ...(moduleSource === undefined ? {} : { source: moduleSource }),
        link: {
            external: false,
            href: `${options.referencePrefix ?? "/docs/api"}/${moduleName}`,
            label: displayName
        }
    };
};
const moduleReflection = (project) => {
    return project;
};
const typedocOptionsFor = (options) => {
    const repositoryUrl = options.repositoryUrl
        ?.replace(/\/+$/u, "")
        .replace(/\.git$/u, "");
    return {
        ...(repositoryUrl === undefined
            ? {}
            : {
                sourceLinkTemplate: `${repositoryUrl}/blob/{gitRevision}/{path}#L{line}`
            }),
        ...(options.typedoc ?? {})
    };
};
export /** @internal */ const generateApiDataset = async (options) => {
    if (options.packages.length === 0) {
        throw new ApiReferenceError("at least one package must be configured");
    }
    const records = [];
    for (const packageInput of options.packages) {
        const app = await Application.bootstrapWithPlugins({
            entryPoints: packageInput.entryPoints.map((entryPoint) => entryPoint.replaceAll("\\", "/")),
            skipErrorChecking: true,
            ...(packageInput.tsconfig === undefined
                ? {}
                : { tsconfig: packageInput.tsconfig }),
            ...typedocOptionsFor(options)
        }, [new TSConfigReader(), new TypeDocReader()]);
        const project = await app.convert();
        if (project === undefined) {
            throw new ApiReferenceError(`TypeDoc could not convert ${packageInput.name}`);
        }
        const moduleEntryPoint = await packageModuleEntryPoint(packageInput);
        records.push(recordFrom(moduleReflection(project), packageInput, options, await moduleDescriptionFrom(moduleEntryPoint), sourceFromPath(moduleEntryPoint, options.repositoryUrl, options.revision, options.sourceRoot)));
    }
    const validation = validateApiRecords(records);
    if (!validation.valid) {
        throw new ApiReferenceError(validation.errors.join("; "));
    }
    const datasetOptions = {
        generatedAt: options.generatedAt ?? new Date().toISOString(),
        ...(options.revision === undefined
            ? {}
            : { sourceRevision: options.revision })
    };
    return createApiDataset(records.sort((left, right) => `${left.packageId}:${left.module}`.localeCompare(`${right.packageId}:${right.module}`)), datasetOptions);
};
//# sourceMappingURL=TypeDoc.js.map
import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { Breadcrumbs, DocsSidebar, OnThisPage } from "./Navigation.js";
import { CopyForLlmButton } from "./CopyForLlm.js";
import { DocCode } from "./Mdx.js";
import { apiReferenceRecordToAgentDocument } from "@sorrell/docs-core";
const declarationHref = (id) => `#${id}`;
const sourceHref = (source) => [
    `${source.repositoryUrl}/blob/`,
    `${source.revision}/`,
    source.file,
    source.line === undefined ? "" : `#L${source.line}`
].join("");
const GitHubIcon = () => (_jsx("svg", { "aria-hidden": "true", viewBox: "0 0 24 24", children: _jsx("path", { d: "M12 .9a11.1 11.1 0 0 0-3.51 21.63c.55.1.76-.24.76-.54v-2.07c-3.09.67-3.74-1.31-3.74-1.31-.5-1.28-1.23-1.62-1.23-1.62-1-.68.08-.67.08-.67 1.11.08 1.7 1.14 1.7 1.14 1 1.69 2.59 1.2 3.22.92.1-.72.39-1.2.7-1.48-2.46-.28-5.04-1.23-5.04-5.47 0-1.21.43-2.2 1.14-2.97-.12-.28-.5-1.4.1-2.93 0 0 .93-.3 3.05 1.14a10.6 10.6 0 0 1 5.54 0c2.12-1.44 3.04-1.14 3.04-1.14.61 1.53.23 2.65.11 2.93.71.77 1.14 1.76 1.14 2.97 0 4.25-2.59 5.19-5.06 5.46.4.34.75 1.02.75 2.05v3.05c0 .3.2.64.76.53A11.1 11.1 0 0 0 12 .9Z", fill: "currentColor" }) }));
const ExternalLinkIcon = () => (_jsx("svg", { "aria-hidden": "true", viewBox: "0 0 16 16", children: _jsx("path", { d: "M9.5 2.5h4v4M13.25 2.75 7 9m1-5H4.5A1.5 1.5 0 0 0 3 5.5v6A1.5 1.5 0 0 0 4.5 13h6a1.5 1.5 0 0 0 1.5-1.5V9", fill: "none", stroke: "currentColor", strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: "1.5" }) }));
const apiNavigation = (record) => record.categories.map((category) => ({
    items: record.declarations
        .filter((declaration) => declaration.categoryId === category.id)
        .map((declaration) => ({
        active: false,
        href: declarationHref(declaration.id),
        label: declaration.name
    })),
    label: category.label
}));
const tocItems = (record) => record.categories.map((category) => ({
    children: record.declarations
        .filter((declaration) => declaration.categoryId === category.id)
        .map((declaration) => ({
        href: declarationHref(declaration.id),
        label: declaration.name
    })),
    href: `#category-${category.id}`,
    label: category.label
}));
const declarationDocument = (record, name, description, signature) => ({
    content: `${description}\n\n${signature}`,
    context: `${record.packageName} ${record.version}`,
    description,
    id: `${record.packageId}:${record.module}:${name}`,
    kind: "api-module",
    metadata: {
        declarationKind: record.declarations.find((declaration) => declaration.name === name)?.kind ?? "unknown"
    },
    title: name,
    url: `${record.link?.href ?? ""}#${name}`,
    version: record.version
});
export /** @internal */ const ApiReferencePage = ({ record, navigation = [] }) => {
    const groups = navigation.length === 0 ? apiNavigation(record) : navigation;
    const document = apiReferenceRecordToAgentDocument(record);
    return (_jsxs("div", { className: "docs-api-page", children: [_jsx(DocsSidebar, { groups: groups, label: "API Reference" }), _jsxs("main", { className: "docs-api-main", children: [_jsx(Breadcrumbs, { items: record.breadcrumbs.map((breadcrumb, index) => index === 1 && !/^[vV]/u.test(breadcrumb.label)
                            ? { ...breadcrumb, label: `V${breadcrumb.label}` }
                            : breadcrumb) }), _jsxs("div", { className: "docs-api-heading-row", children: [_jsxs("div", { children: [_jsx("h1", { children: record.displayName }), record.summary === undefined ? null : (_jsx("p", { children: record.summary }))] }), _jsx(CopyForLlmButton, { document: document })] }), _jsxs("div", { className: "docs-api-meta", children: [_jsxs("span", { children: [record.exportCount, " exports"] }), record.introductionVersion === undefined ? null : (_jsxs("span", { children: ["Added in v", record.introductionVersion] })), record.source === undefined ? null : (_jsxs("a", { className: "docs-source-link", href: sourceHref(record.source), children: [_jsx(GitHubIcon, {}), "Source"] }))] }), record.categories.map((category) => (_jsxs("section", { className: "docs-api-category", id: `category-${category.id}`, children: [_jsx("h2", { children: category.label }), record.declarations
                                .filter((declaration) => declaration.categoryId === category.id)
                                .map((declaration) => (_jsxs("article", { className: "docs-api-declaration", id: declaration.id, children: [_jsxs("div", { className: "docs-declaration-heading", children: [_jsxs("h3", { children: [_jsx("a", { "aria-label": `Link to ${declaration.name}`, className: "docs-declaration-anchor", href: declarationHref(declaration.id), children: "#" }), declaration.name, _jsx("span", { className: "docs-kind-badge", children: declaration.kind.toUpperCase() })] }), _jsxs("div", { className: "docs-declaration-links", children: [_jsxs("span", { children: ["Added in v", declaration.introductionVersion ?? record.version] }), declaration.source ===
                                                        undefined ? null : (_jsxs("a", { className: "docs-source-link", href: sourceHref(declaration.source), children: ["Source", _jsx(ExternalLinkIcon, {})] })), _jsx(CopyForLlmButton, { document: declarationDocument(record, declaration.name, declaration.description, declaration.signature) })] })] }), _jsx("p", { children: declaration.description }), _jsx("h4", { children: "Signature" }), _jsx(DocCode, { language: "typescript", children: declaration.signature })] }, declaration.id)))] }, category.id)))] }), _jsx(OnThisPage, { items: tocItems(record) })] }));
};
//# sourceMappingURL=ApiReference.js.map
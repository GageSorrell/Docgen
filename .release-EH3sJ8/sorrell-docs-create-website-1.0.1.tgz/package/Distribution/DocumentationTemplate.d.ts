/**
 * Loads the generated Astro documentation typography templates.
 *
 * @module @sorrell/docs-create-website/DocumentationTemplate
 *
 * @file      DocumentationTemplate.ts
 * @author    Gage Sorrell <gage@sorrell.sh>
 * @copyright (c) 2026 Gage Sorrell
 * @license   MIT
 */
import type { DocsConfig } from "@sorrell/docs-core";
import type { GeneratedWebsiteFile } from "./Types.js";
export declare const documentationTemplateFiles: (config: DocsConfig) => ReadonlyArray<GeneratedWebsiteFile>;
//# sourceMappingURL=DocumentationTemplate.d.ts.map